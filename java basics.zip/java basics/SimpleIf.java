public class SimpleIf {
    public static void main(String[] args) {
        int age=20;

        if(age>=18){
            System.out.println("Eligible for vote");
        }
    }
}
public class StringBasics{
    public static void main(String[] args) {
        String name = "Srujan";
        System.out.println(name);
    }
}
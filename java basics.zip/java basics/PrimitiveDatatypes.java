public class PrimitiveDatatypes{
    public static void main(String[] args) {
        int age=18;
        System.out.println(age);
        double price=99.05;
        System.out.println(price);
        boolean isActive= true;
        System.out.println(isActive);
        char alpha= 'A';
        System.out.println(alpha);

    }
}